// 자바스크립트
alert("경고");

let value1 = document.getElementById("value1");
let value2 = document.getElementById("value2");
let final = document.getElementById("final");
let e = document.getElementById("clear3");
let clear = document.getElementById("clear");

// let plus = document.getElementById("plus");/
let equal = document.getElementById("equal");

equal.addEventListener('click', add);
clear.addEventListener('click', clear2);
e.addEventListener('click', display);
let a3 = 0;
function add() {
    let a1 = value1.value;
    let a2 = value2.value;

    a3 = Math.abs(a1) + Math.abs(a2);
    final.value = a3;
}
function clear2() {
    value1.value = " ";
    value2.value = " ";
    final.value = " ";
}
function display() {
    alert(`값은 ${final.value} 입니다`)
}